# kudryavkaDiscordBot

This bot was created to talk with Japanese friends.

Please use this bot a lot for those who cannot communicate in Japanese and Korean.

I hope you have a good relationship.

I would like to express my gratitude to my Japanese friend who motivated me.

https://geek-space.fanbox.cc/

## Quick Start  
        
downlaod : https://github.com/rinechran/kudryavkaDiscordBot/releases/tag/1.0
    
1. Discord Bot Get Token
   -  https://discord.com/developers/applications 
2. Naver API register
    - https://developers.naver.com/apps/#/register
3. KEY SAVE (Choose one of the two)
   1. json.file

        Create bot.json in the config folder, which is the relative path of the executable file. 
        ```
        {
            "DISCORD_TOKEN": "<DISCORD TOKEN>",
            "NAVER_CLIENT_ID": "<NAVER CLINET_ID>",
            "NAVER_CLINET_SECRET": "<NAVER CLINET_SECRET>"
        }
        ```
   2. environmnet
        ```
            "DISCORD_TOKEN": "<DISCORD TOKEN>",
            "NAVER_CLIENT_ID": "<NAVER CLINET_ID>",
            "NAVER_CLINET_SECRET": "<NAVER CLINET_SECRET>"
        ```
## Docker

Not implement

## How To Contribute

Not implement

# License

MIT License

Copyright (c) 2020 rinechran

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.